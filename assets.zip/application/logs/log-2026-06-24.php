<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-06-24 05:03:48 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\wamp64\www\Office_management_system\system\core\URI.php 102
ERROR - 2026-06-24 05:03:48 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\wamp64\www\Office_management_system\system\core\Router.php 128
ERROR - 2026-06-24 05:03:49 --> Severity: 8192 --> Creation of dynamic property Auth::$benchmark is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:03:49 --> Severity: 8192 --> Creation of dynamic property Auth::$hooks is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:03:49 --> Severity: 8192 --> Creation of dynamic property Auth::$config is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:03:49 --> Severity: 8192 --> Creation of dynamic property Auth::$log is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:03:49 --> Severity: 8192 --> Creation of dynamic property Auth::$utf8 is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:03:49 --> Severity: 8192 --> Creation of dynamic property Auth::$uri is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:03:49 --> Severity: 8192 --> Creation of dynamic property Auth::$exceptions is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:03:49 --> Severity: 8192 --> Creation of dynamic property Auth::$router is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:03:49 --> Severity: 8192 --> Creation of dynamic property Auth::$output is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:03:49 --> Severity: 8192 --> Creation of dynamic property Auth::$security is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:03:49 --> Severity: 8192 --> Creation of dynamic property Auth::$input is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:03:49 --> Severity: 8192 --> Creation of dynamic property Auth::$lang is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:03:51 --> Severity: 8192 --> Creation of dynamic property Auth::$db is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 397
ERROR - 2026-06-24 05:03:51 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\wamp64\www\Office_management_system\system\database\DB_driver.php 372
ERROR - 2026-06-24 05:03:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 303
ERROR - 2026-06-24 05:03:51 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 328
ERROR - 2026-06-24 05:03:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 355
ERROR - 2026-06-24 05:03:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 365
ERROR - 2026-06-24 05:03:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 366
ERROR - 2026-06-24 05:03:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 367
ERROR - 2026-06-24 05:03:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 368
ERROR - 2026-06-24 05:03:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 426
ERROR - 2026-06-24 05:03:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\drivers\Session_files_driver.php 109
ERROR - 2026-06-24 05:03:51 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 110
ERROR - 2026-06-24 05:03:51 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 137
ERROR - 2026-06-24 05:03:51 --> Severity: 8192 --> Creation of dynamic property Auth::$session is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 1284
ERROR - 2026-06-24 05:03:52 --> Severity: 8192 --> Creation of dynamic property Auth::$User_model is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 359
ERROR - 2026-06-24 05:03:52 --> Severity: 8192 --> Creation of dynamic property Auth::$settings is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 359
ERROR - 2026-06-24 05:03:52 --> Severity: 8192 --> Creation of dynamic property Auth::$audit is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 359
ERROR - 2026-06-24 10:33:52 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 932
ERROR - 2026-06-24 10:33:52 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 932
ERROR - 2026-06-24 10:33:52 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 932
ERROR - 2026-06-24 10:33:52 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 932
ERROR - 2026-06-24 10:33:52 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 932
ERROR - 2026-06-24 10:33:52 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 932
ERROR - 2026-06-24 10:33:52 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 932
ERROR - 2026-06-24 10:33:52 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$exceptions is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 932
ERROR - 2026-06-24 10:33:52 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 932
ERROR - 2026-06-24 10:33:52 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 932
ERROR - 2026-06-24 10:33:52 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 932
ERROR - 2026-06-24 10:33:52 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 932
ERROR - 2026-06-24 10:33:52 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 932
ERROR - 2026-06-24 10:33:52 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 932
ERROR - 2026-06-24 10:33:52 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 932
ERROR - 2026-06-24 10:33:52 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$User_model is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 932
ERROR - 2026-06-24 10:33:52 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$settings is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 932
ERROR - 2026-06-24 10:33:52 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$audit is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 932
ERROR - 2026-06-24 05:03:58 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\wamp64\www\Office_management_system\system\core\URI.php 102
ERROR - 2026-06-24 05:03:58 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\wamp64\www\Office_management_system\system\core\Router.php 128
ERROR - 2026-06-24 05:03:58 --> Severity: 8192 --> Creation of dynamic property Errors::$benchmark is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:03:58 --> Severity: 8192 --> Creation of dynamic property Errors::$hooks is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:03:58 --> Severity: 8192 --> Creation of dynamic property Errors::$config is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:03:58 --> Severity: 8192 --> Creation of dynamic property Errors::$log is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:03:58 --> Severity: 8192 --> Creation of dynamic property Errors::$utf8 is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:03:58 --> Severity: 8192 --> Creation of dynamic property Errors::$uri is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:03:58 --> Severity: 8192 --> Creation of dynamic property Errors::$exceptions is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:03:58 --> Severity: 8192 --> Creation of dynamic property Errors::$router is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:03:58 --> Severity: 8192 --> Creation of dynamic property Errors::$output is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:03:58 --> Severity: 8192 --> Creation of dynamic property Errors::$security is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:03:58 --> Severity: 8192 --> Creation of dynamic property Errors::$input is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:03:58 --> Severity: 8192 --> Creation of dynamic property Errors::$lang is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:03:58 --> Severity: 8192 --> Creation of dynamic property Errors::$db is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 397
ERROR - 2026-06-24 05:03:58 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\wamp64\www\Office_management_system\system\database\DB_driver.php 372
ERROR - 2026-06-24 05:03:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 303
ERROR - 2026-06-24 05:03:58 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 328
ERROR - 2026-06-24 05:03:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 355
ERROR - 2026-06-24 05:03:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 365
ERROR - 2026-06-24 05:03:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 366
ERROR - 2026-06-24 05:03:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 367
ERROR - 2026-06-24 05:03:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 368
ERROR - 2026-06-24 05:03:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 426
ERROR - 2026-06-24 05:03:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\drivers\Session_files_driver.php 109
ERROR - 2026-06-24 05:03:58 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 110
ERROR - 2026-06-24 05:03:58 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 137
ERROR - 2026-06-24 05:03:58 --> Severity: 8192 --> Creation of dynamic property Errors::$session is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 1284
ERROR - 2026-06-24 10:33:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\Office_management_system\system\core\Exceptions.php:272) C:\wamp64\www\Office_management_system\system\helpers\url_helper.php 565
ERROR - 2026-06-24 05:04:04 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\wamp64\www\Office_management_system\system\core\URI.php 102
ERROR - 2026-06-24 05:04:04 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\wamp64\www\Office_management_system\system\core\Router.php 128
ERROR - 2026-06-24 05:04:04 --> Severity: 8192 --> Creation of dynamic property Auth::$benchmark is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:04 --> Severity: 8192 --> Creation of dynamic property Auth::$hooks is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:04 --> Severity: 8192 --> Creation of dynamic property Auth::$config is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:04 --> Severity: 8192 --> Creation of dynamic property Auth::$log is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:04 --> Severity: 8192 --> Creation of dynamic property Auth::$utf8 is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:04 --> Severity: 8192 --> Creation of dynamic property Auth::$uri is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:04 --> Severity: 8192 --> Creation of dynamic property Auth::$exceptions is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:04 --> Severity: 8192 --> Creation of dynamic property Auth::$router is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:04 --> Severity: 8192 --> Creation of dynamic property Auth::$output is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:04 --> Severity: 8192 --> Creation of dynamic property Auth::$security is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:04 --> Severity: 8192 --> Creation of dynamic property Auth::$input is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:04 --> Severity: 8192 --> Creation of dynamic property Auth::$lang is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:04 --> Severity: 8192 --> Creation of dynamic property Auth::$db is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 397
ERROR - 2026-06-24 05:04:04 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\wamp64\www\Office_management_system\system\database\DB_driver.php 372
ERROR - 2026-06-24 05:04:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 303
ERROR - 2026-06-24 05:04:04 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 328
ERROR - 2026-06-24 05:04:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 355
ERROR - 2026-06-24 05:04:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 365
ERROR - 2026-06-24 05:04:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 366
ERROR - 2026-06-24 05:04:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 367
ERROR - 2026-06-24 05:04:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 368
ERROR - 2026-06-24 05:04:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 426
ERROR - 2026-06-24 05:04:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\drivers\Session_files_driver.php 109
ERROR - 2026-06-24 05:04:04 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 110
ERROR - 2026-06-24 05:04:04 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 137
ERROR - 2026-06-24 05:04:04 --> Severity: 8192 --> Creation of dynamic property Auth::$session is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 1284
ERROR - 2026-06-24 05:04:04 --> Severity: 8192 --> Creation of dynamic property Auth::$User_model is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 359
ERROR - 2026-06-24 05:04:04 --> Severity: 8192 --> Creation of dynamic property Auth::$settings is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 359
ERROR - 2026-06-24 05:04:04 --> Severity: 8192 --> Creation of dynamic property Auth::$audit is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 359
ERROR - 2026-06-24 10:34:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\Office_management_system\system\core\Exceptions.php:272) C:\wamp64\www\Office_management_system\application\controllers\Auth.php 120
ERROR - 2026-06-24 05:04:55 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\wamp64\www\Office_management_system\system\core\URI.php 102
ERROR - 2026-06-24 05:04:55 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\wamp64\www\Office_management_system\system\core\Router.php 128
ERROR - 2026-06-24 05:04:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\Office_management_system\system\core\Exceptions.php:76) C:\wamp64\www\Office_management_system\system\core\Security.php 278
ERROR - 2026-06-24 05:04:55 --> Severity: 8192 --> Creation of dynamic property Auth::$benchmark is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:55 --> Severity: 8192 --> Creation of dynamic property Auth::$hooks is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:55 --> Severity: 8192 --> Creation of dynamic property Auth::$config is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:55 --> Severity: 8192 --> Creation of dynamic property Auth::$log is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:55 --> Severity: 8192 --> Creation of dynamic property Auth::$utf8 is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:55 --> Severity: 8192 --> Creation of dynamic property Auth::$uri is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:55 --> Severity: 8192 --> Creation of dynamic property Auth::$exceptions is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:55 --> Severity: 8192 --> Creation of dynamic property Auth::$router is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:55 --> Severity: 8192 --> Creation of dynamic property Auth::$output is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:55 --> Severity: 8192 --> Creation of dynamic property Auth::$security is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:55 --> Severity: 8192 --> Creation of dynamic property Auth::$input is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:55 --> Severity: 8192 --> Creation of dynamic property Auth::$lang is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:55 --> Severity: 8192 --> Creation of dynamic property Auth::$db is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 397
ERROR - 2026-06-24 05:04:56 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\wamp64\www\Office_management_system\system\database\DB_driver.php 372
ERROR - 2026-06-24 05:04:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 303
ERROR - 2026-06-24 05:04:56 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 328
ERROR - 2026-06-24 05:04:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 355
ERROR - 2026-06-24 05:04:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 365
ERROR - 2026-06-24 05:04:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 366
ERROR - 2026-06-24 05:04:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 367
ERROR - 2026-06-24 05:04:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 368
ERROR - 2026-06-24 05:04:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 426
ERROR - 2026-06-24 05:04:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\drivers\Session_files_driver.php 109
ERROR - 2026-06-24 05:04:56 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 110
ERROR - 2026-06-24 05:04:56 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 137
ERROR - 2026-06-24 05:04:56 --> Severity: 8192 --> Creation of dynamic property Auth::$session is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 1284
ERROR - 2026-06-24 05:04:56 --> Severity: 8192 --> Creation of dynamic property Auth::$User_model is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 359
ERROR - 2026-06-24 05:04:56 --> Severity: 8192 --> Creation of dynamic property Auth::$settings is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 359
ERROR - 2026-06-24 05:04:56 --> Severity: 8192 --> Creation of dynamic property Auth::$audit is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 359
ERROR - 2026-06-24 10:34:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\Office_management_system\system\core\Exceptions.php:76) C:\wamp64\www\Office_management_system\system\helpers\url_helper.php 565
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\wamp64\www\Office_management_system\system\core\URI.php 102
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\wamp64\www\Office_management_system\system\core\Router.php 128
ERROR - 2026-06-24 05:04:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\Office_management_system\system\core\Exceptions.php:76) C:\wamp64\www\Office_management_system\system\core\Security.php 278
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property Auth::$benchmark is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property Auth::$hooks is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property Auth::$config is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property Auth::$log is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property Auth::$utf8 is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property Auth::$uri is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property Auth::$exceptions is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property Auth::$router is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property Auth::$output is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property Auth::$security is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property Auth::$input is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property Auth::$lang is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property Auth::$db is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 397
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\wamp64\www\Office_management_system\system\database\DB_driver.php 372
ERROR - 2026-06-24 05:04:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 303
ERROR - 2026-06-24 05:04:58 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 328
ERROR - 2026-06-24 05:04:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 355
ERROR - 2026-06-24 05:04:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 365
ERROR - 2026-06-24 05:04:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 366
ERROR - 2026-06-24 05:04:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 367
ERROR - 2026-06-24 05:04:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 368
ERROR - 2026-06-24 05:04:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 426
ERROR - 2026-06-24 05:04:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\drivers\Session_files_driver.php 109
ERROR - 2026-06-24 05:04:58 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 110
ERROR - 2026-06-24 05:04:58 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 137
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property Auth::$session is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 1284
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property Auth::$User_model is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 359
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property Auth::$settings is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 359
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property Auth::$audit is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 359
ERROR - 2026-06-24 10:34:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\Office_management_system\system\core\Exceptions.php:76) C:\wamp64\www\Office_management_system\system\helpers\url_helper.php 565
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\wamp64\www\Office_management_system\system\core\URI.php 102
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\wamp64\www\Office_management_system\system\core\Router.php 128
ERROR - 2026-06-24 05:04:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\Office_management_system\system\core\Exceptions.php:76) C:\wamp64\www\Office_management_system\system\core\Security.php 278
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property Auth::$benchmark is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property Auth::$hooks is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property Auth::$config is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property Auth::$log is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property Auth::$utf8 is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property Auth::$uri is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property Auth::$exceptions is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property Auth::$router is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property Auth::$output is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property Auth::$security is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property Auth::$input is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property Auth::$lang is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property Auth::$db is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 397
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\wamp64\www\Office_management_system\system\database\DB_driver.php 372
ERROR - 2026-06-24 05:04:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 303
ERROR - 2026-06-24 05:04:58 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 328
ERROR - 2026-06-24 05:04:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 355
ERROR - 2026-06-24 05:04:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 365
ERROR - 2026-06-24 05:04:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 366
ERROR - 2026-06-24 05:04:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 367
ERROR - 2026-06-24 05:04:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 368
ERROR - 2026-06-24 05:04:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 426
ERROR - 2026-06-24 05:04:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\drivers\Session_files_driver.php 109
ERROR - 2026-06-24 05:04:58 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 110
ERROR - 2026-06-24 05:04:58 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 137
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property Auth::$session is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 1284
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property Auth::$User_model is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 359
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property Auth::$settings is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 359
ERROR - 2026-06-24 05:04:58 --> Severity: 8192 --> Creation of dynamic property Auth::$audit is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 359
ERROR - 2026-06-24 10:34:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\Office_management_system\system\core\Exceptions.php:76) C:\wamp64\www\Office_management_system\system\helpers\url_helper.php 565
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\wamp64\www\Office_management_system\system\core\URI.php 102
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\wamp64\www\Office_management_system\system\core\Router.php 128
ERROR - 2026-06-24 05:04:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\Office_management_system\system\core\Exceptions.php:76) C:\wamp64\www\Office_management_system\system\core\Security.php 278
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property Auth::$benchmark is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property Auth::$hooks is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property Auth::$config is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property Auth::$log is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property Auth::$utf8 is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property Auth::$uri is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property Auth::$exceptions is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property Auth::$router is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property Auth::$output is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property Auth::$security is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property Auth::$input is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property Auth::$lang is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property Auth::$db is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 397
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\wamp64\www\Office_management_system\system\database\DB_driver.php 372
ERROR - 2026-06-24 05:04:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 303
ERROR - 2026-06-24 05:04:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 328
ERROR - 2026-06-24 05:04:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 355
ERROR - 2026-06-24 05:04:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 365
ERROR - 2026-06-24 05:04:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 366
ERROR - 2026-06-24 05:04:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 367
ERROR - 2026-06-24 05:04:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 368
ERROR - 2026-06-24 05:04:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 426
ERROR - 2026-06-24 05:04:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\drivers\Session_files_driver.php 109
ERROR - 2026-06-24 05:04:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 110
ERROR - 2026-06-24 05:04:59 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 137
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property Auth::$session is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 1284
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property Auth::$User_model is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 359
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property Auth::$settings is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 359
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property Auth::$audit is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 359
ERROR - 2026-06-24 10:34:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\Office_management_system\system\core\Exceptions.php:76) C:\wamp64\www\Office_management_system\system\helpers\url_helper.php 565
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\wamp64\www\Office_management_system\system\core\URI.php 102
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\wamp64\www\Office_management_system\system\core\Router.php 128
ERROR - 2026-06-24 05:04:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\Office_management_system\system\core\Exceptions.php:76) C:\wamp64\www\Office_management_system\system\core\Security.php 278
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property Auth::$benchmark is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property Auth::$hooks is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property Auth::$config is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property Auth::$log is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property Auth::$utf8 is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property Auth::$uri is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property Auth::$exceptions is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property Auth::$router is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property Auth::$output is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property Auth::$security is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property Auth::$input is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property Auth::$lang is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property Auth::$db is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 397
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\wamp64\www\Office_management_system\system\database\DB_driver.php 372
ERROR - 2026-06-24 05:04:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 303
ERROR - 2026-06-24 05:04:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 328
ERROR - 2026-06-24 05:04:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 355
ERROR - 2026-06-24 05:04:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 365
ERROR - 2026-06-24 05:04:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 366
ERROR - 2026-06-24 05:04:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 367
ERROR - 2026-06-24 05:04:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 368
ERROR - 2026-06-24 05:04:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 426
ERROR - 2026-06-24 05:04:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\drivers\Session_files_driver.php 109
ERROR - 2026-06-24 05:04:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 110
ERROR - 2026-06-24 05:04:59 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 137
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property Auth::$session is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 1284
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property Auth::$User_model is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 359
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property Auth::$settings is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 359
ERROR - 2026-06-24 05:04:59 --> Severity: 8192 --> Creation of dynamic property Auth::$audit is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 359
ERROR - 2026-06-24 10:34:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\Office_management_system\system\core\Exceptions.php:76) C:\wamp64\www\Office_management_system\system\helpers\url_helper.php 565
ERROR - 2026-06-24 05:05:14 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\wamp64\www\Office_management_system\system\core\URI.php 102
ERROR - 2026-06-24 05:05:14 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\wamp64\www\Office_management_system\system\core\Router.php 128
ERROR - 2026-06-24 05:05:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\Office_management_system\system\core\Exceptions.php:76) C:\wamp64\www\Office_management_system\system\core\Security.php 278
ERROR - 2026-06-24 05:05:14 --> Severity: 8192 --> Creation of dynamic property Auth::$benchmark is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:05:14 --> Severity: 8192 --> Creation of dynamic property Auth::$hooks is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:05:14 --> Severity: 8192 --> Creation of dynamic property Auth::$config is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:05:14 --> Severity: 8192 --> Creation of dynamic property Auth::$log is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:05:14 --> Severity: 8192 --> Creation of dynamic property Auth::$utf8 is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:05:14 --> Severity: 8192 --> Creation of dynamic property Auth::$uri is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:05:14 --> Severity: 8192 --> Creation of dynamic property Auth::$exceptions is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:05:14 --> Severity: 8192 --> Creation of dynamic property Auth::$router is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:05:14 --> Severity: 8192 --> Creation of dynamic property Auth::$output is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:05:14 --> Severity: 8192 --> Creation of dynamic property Auth::$security is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:05:14 --> Severity: 8192 --> Creation of dynamic property Auth::$input is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:05:14 --> Severity: 8192 --> Creation of dynamic property Auth::$lang is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:05:14 --> Severity: 8192 --> Creation of dynamic property Auth::$db is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 397
ERROR - 2026-06-24 05:05:14 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\wamp64\www\Office_management_system\system\database\DB_driver.php 372
ERROR - 2026-06-24 05:05:14 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 303
ERROR - 2026-06-24 05:05:14 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 328
ERROR - 2026-06-24 05:05:14 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 355
ERROR - 2026-06-24 05:05:14 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 365
ERROR - 2026-06-24 05:05:14 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 366
ERROR - 2026-06-24 05:05:14 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 367
ERROR - 2026-06-24 05:05:14 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 368
ERROR - 2026-06-24 05:05:14 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 426
ERROR - 2026-06-24 05:05:14 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\drivers\Session_files_driver.php 109
ERROR - 2026-06-24 05:05:14 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 110
ERROR - 2026-06-24 05:05:14 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 137
ERROR - 2026-06-24 05:05:14 --> Severity: 8192 --> Creation of dynamic property Auth::$session is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 1284
ERROR - 2026-06-24 05:05:14 --> Severity: 8192 --> Creation of dynamic property Auth::$User_model is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 359
ERROR - 2026-06-24 05:05:14 --> Severity: 8192 --> Creation of dynamic property Auth::$settings is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 359
ERROR - 2026-06-24 05:05:14 --> Severity: 8192 --> Creation of dynamic property Auth::$audit is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 359
ERROR - 2026-06-24 10:35:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\Office_management_system\system\core\Exceptions.php:76) C:\wamp64\www\Office_management_system\system\helpers\url_helper.php 565
ERROR - 2026-06-24 05:05:22 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\wamp64\www\Office_management_system\system\core\URI.php 102
ERROR - 2026-06-24 05:05:22 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\wamp64\www\Office_management_system\system\core\Router.php 128
ERROR - 2026-06-24 05:05:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\Office_management_system\system\core\Exceptions.php:76) C:\wamp64\www\Office_management_system\system\core\Security.php 278
ERROR - 2026-06-24 05:05:22 --> Severity: 8192 --> Creation of dynamic property Auth::$benchmark is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:05:22 --> Severity: 8192 --> Creation of dynamic property Auth::$hooks is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:05:22 --> Severity: 8192 --> Creation of dynamic property Auth::$config is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:05:22 --> Severity: 8192 --> Creation of dynamic property Auth::$log is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:05:22 --> Severity: 8192 --> Creation of dynamic property Auth::$utf8 is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:05:22 --> Severity: 8192 --> Creation of dynamic property Auth::$uri is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:05:22 --> Severity: 8192 --> Creation of dynamic property Auth::$exceptions is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:05:22 --> Severity: 8192 --> Creation of dynamic property Auth::$router is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:05:22 --> Severity: 8192 --> Creation of dynamic property Auth::$output is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:05:22 --> Severity: 8192 --> Creation of dynamic property Auth::$security is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:05:22 --> Severity: 8192 --> Creation of dynamic property Auth::$input is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:05:22 --> Severity: 8192 --> Creation of dynamic property Auth::$lang is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:05:22 --> Severity: 8192 --> Creation of dynamic property Auth::$db is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 397
ERROR - 2026-06-24 05:05:22 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\wamp64\www\Office_management_system\system\database\DB_driver.php 372
ERROR - 2026-06-24 05:05:22 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 303
ERROR - 2026-06-24 05:05:22 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 328
ERROR - 2026-06-24 05:05:22 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 355
ERROR - 2026-06-24 05:05:22 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 365
ERROR - 2026-06-24 05:05:22 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 366
ERROR - 2026-06-24 05:05:22 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 367
ERROR - 2026-06-24 05:05:22 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 368
ERROR - 2026-06-24 05:05:22 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 426
ERROR - 2026-06-24 05:05:22 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\drivers\Session_files_driver.php 109
ERROR - 2026-06-24 05:05:22 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 110
ERROR - 2026-06-24 05:05:22 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 137
ERROR - 2026-06-24 05:05:22 --> Severity: 8192 --> Creation of dynamic property Auth::$session is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 1284
ERROR - 2026-06-24 05:05:22 --> Severity: 8192 --> Creation of dynamic property Auth::$User_model is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 359
ERROR - 2026-06-24 05:05:22 --> Severity: 8192 --> Creation of dynamic property Auth::$settings is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 359
ERROR - 2026-06-24 05:05:22 --> Severity: 8192 --> Creation of dynamic property Auth::$audit is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 359
ERROR - 2026-06-24 10:35:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\Office_management_system\system\core\Exceptions.php:76) C:\wamp64\www\Office_management_system\system\helpers\url_helper.php 565
ERROR - 2026-06-24 05:05:56 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\wamp64\www\Office_management_system\system\core\URI.php 102
ERROR - 2026-06-24 05:05:56 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\wamp64\www\Office_management_system\system\core\Router.php 128
ERROR - 2026-06-24 05:05:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\Office_management_system\system\core\Exceptions.php:76) C:\wamp64\www\Office_management_system\system\core\Security.php 278
ERROR - 2026-06-24 05:05:56 --> Severity: 8192 --> Creation of dynamic property Auth::$benchmark is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:05:56 --> Severity: 8192 --> Creation of dynamic property Auth::$hooks is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:05:56 --> Severity: 8192 --> Creation of dynamic property Auth::$config is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:05:56 --> Severity: 8192 --> Creation of dynamic property Auth::$log is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:05:56 --> Severity: 8192 --> Creation of dynamic property Auth::$utf8 is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:05:56 --> Severity: 8192 --> Creation of dynamic property Auth::$uri is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:05:56 --> Severity: 8192 --> Creation of dynamic property Auth::$exceptions is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:05:56 --> Severity: 8192 --> Creation of dynamic property Auth::$router is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:05:56 --> Severity: 8192 --> Creation of dynamic property Auth::$output is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:05:56 --> Severity: 8192 --> Creation of dynamic property Auth::$security is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:05:56 --> Severity: 8192 --> Creation of dynamic property Auth::$input is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:05:56 --> Severity: 8192 --> Creation of dynamic property Auth::$lang is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:05:56 --> Severity: 8192 --> Creation of dynamic property Auth::$db is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 397
ERROR - 2026-06-24 05:05:56 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\wamp64\www\Office_management_system\system\database\DB_driver.php 372
ERROR - 2026-06-24 05:05:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 303
ERROR - 2026-06-24 05:05:56 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 328
ERROR - 2026-06-24 05:05:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 355
ERROR - 2026-06-24 05:05:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 365
ERROR - 2026-06-24 05:05:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 366
ERROR - 2026-06-24 05:05:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 367
ERROR - 2026-06-24 05:05:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 368
ERROR - 2026-06-24 05:05:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 426
ERROR - 2026-06-24 05:05:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\drivers\Session_files_driver.php 109
ERROR - 2026-06-24 05:05:56 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 110
ERROR - 2026-06-24 05:05:56 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 137
ERROR - 2026-06-24 05:05:56 --> Severity: 8192 --> Creation of dynamic property Auth::$session is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 1284
ERROR - 2026-06-24 05:05:56 --> Severity: 8192 --> Creation of dynamic property Auth::$User_model is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 359
ERROR - 2026-06-24 05:05:56 --> Severity: 8192 --> Creation of dynamic property Auth::$settings is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 359
ERROR - 2026-06-24 05:05:56 --> Severity: 8192 --> Creation of dynamic property Auth::$audit is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 359
ERROR - 2026-06-24 10:35:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\Office_management_system\system\core\Exceptions.php:76) C:\wamp64\www\Office_management_system\system\helpers\url_helper.php 565
ERROR - 2026-06-24 05:09:29 --> Severity: Deprecated --> strtolower(): Passing null to parameter #1 ($string) of type string is deprecated C:\wamp64\www\Office_management_system\system\core\Input.php 911
ERROR - 2026-06-24 05:09:45 --> Severity: Deprecated --> strtolower(): Passing null to parameter #1 ($string) of type string is deprecated C:\wamp64\www\Office_management_system\system\core\Input.php 911
ERROR - 2026-06-24 05:10:42 --> Severity: Deprecated --> ini_set(): session.sid_length INI setting is deprecated C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 426
ERROR - 2026-06-24 05:10:42 --> Severity: Deprecated --> ini_set(): session.sid_length INI setting is deprecated C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 426
ERROR - 2026-06-24 05:10:42 --> Severity: Deprecated --> ini_set(): session.sid_length INI setting is deprecated C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 426
ERROR - 2026-06-24 05:10:42 --> Severity: Deprecated --> ini_set(): session.sid_length INI setting is deprecated C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 426
ERROR - 2026-06-24 05:15:33 --> Severity: Deprecated --> ini_set(): session.sid_length INI setting is deprecated C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 426
ERROR - 2026-06-24 05:15:33 --> Severity: Deprecated --> ini_set(): session.sid_length INI setting is deprecated C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 426
ERROR - 2026-06-24 05:15:33 --> Severity: Deprecated --> ini_set(): session.sid_length INI setting is deprecated C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 426
ERROR - 2026-06-24 05:15:49 --> Severity: Deprecated --> ini_set(): session.sid_length INI setting is deprecated C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 426
ERROR - 2026-06-24 05:15:49 --> Severity: Deprecated --> ini_set(): session.sid_length INI setting is deprecated C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 426
ERROR - 2026-06-24 05:15:49 --> Severity: Deprecated --> ini_set(): session.sid_length INI setting is deprecated C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 426
ERROR - 2026-06-24 05:15:53 --> Severity: Deprecated --> ini_set(): session.sid_length INI setting is deprecated C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 426
ERROR - 2026-06-24 05:15:58 --> Severity: Deprecated --> ini_set(): session.sid_length INI setting is deprecated C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 426
ERROR - 2026-06-24 05:15:58 --> Severity: Deprecated --> ini_set(): session.sid_length INI setting is deprecated C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 426
ERROR - 2026-06-24 10:45:58 --> Severity: Deprecated --> Creation of dynamic property CI_Cache::$file is deprecated C:\wamp64\www\Office_management_system\system\libraries\Driver.php 189
ERROR - 2026-06-24 05:16:00 --> Severity: Deprecated --> ini_set(): session.sid_length INI setting is deprecated C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 426
ERROR - 2026-06-24 10:46:00 --> Severity: Deprecated --> Creation of dynamic property CI_Cache::$file is deprecated C:\wamp64\www\Office_management_system\system\libraries\Driver.php 189
ERROR - 2026-06-24 05:16:00 --> Severity: Deprecated --> ini_set(): session.sid_length INI setting is deprecated C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 426
ERROR - 2026-06-24 05:16:03 --> Severity: Deprecated --> ini_set(): session.sid_length INI setting is deprecated C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 426
ERROR - 2026-06-24 05:16:06 --> Severity: Deprecated --> ini_set(): session.sid_length INI setting is deprecated C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 426
ERROR - 2026-06-24 10:46:19 --> Severity: Deprecated --> Creation of dynamic property CI_Cache::$file is deprecated C:\wamp64\www\Office_management_system\system\libraries\Driver.php 189
ERROR - 2026-06-24 05:16:42 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\wamp64\www\Office_management_system\system\core\URI.php 102
ERROR - 2026-06-24 05:16:42 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\wamp64\www\Office_management_system\system\core\Router.php 128
ERROR - 2026-06-24 05:16:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\Office_management_system\system\core\Exceptions.php:76) C:\wamp64\www\Office_management_system\system\core\Security.php 278
ERROR - 2026-06-24 05:16:42 --> Severity: 8192 --> Creation of dynamic property Calls::$benchmark is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:16:42 --> Severity: 8192 --> Creation of dynamic property Calls::$hooks is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:16:42 --> Severity: 8192 --> Creation of dynamic property Calls::$config is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:16:42 --> Severity: 8192 --> Creation of dynamic property Calls::$log is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:16:42 --> Severity: 8192 --> Creation of dynamic property Calls::$utf8 is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:16:42 --> Severity: 8192 --> Creation of dynamic property Calls::$uri is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:16:42 --> Severity: 8192 --> Creation of dynamic property Calls::$exceptions is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:16:42 --> Severity: 8192 --> Creation of dynamic property Calls::$router is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:16:42 --> Severity: 8192 --> Creation of dynamic property Calls::$output is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:16:42 --> Severity: 8192 --> Creation of dynamic property Calls::$security is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:16:42 --> Severity: 8192 --> Creation of dynamic property Calls::$input is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:16:42 --> Severity: 8192 --> Creation of dynamic property Calls::$lang is deprecated C:\wamp64\www\Office_management_system\system\core\Controller.php 83
ERROR - 2026-06-24 05:16:42 --> Severity: 8192 --> Creation of dynamic property Calls::$db is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 397
ERROR - 2026-06-24 05:16:42 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\wamp64\www\Office_management_system\system\database\DB_driver.php 372
ERROR - 2026-06-24 05:16:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 303
ERROR - 2026-06-24 05:16:42 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 328
ERROR - 2026-06-24 05:16:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 355
ERROR - 2026-06-24 05:16:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 365
ERROR - 2026-06-24 05:16:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 366
ERROR - 2026-06-24 05:16:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 367
ERROR - 2026-06-24 05:16:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 368
ERROR - 2026-06-24 05:16:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 426
ERROR - 2026-06-24 05:16:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\drivers\Session_files_driver.php 109
ERROR - 2026-06-24 05:16:42 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 110
ERROR - 2026-06-24 05:16:42 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\wamp64\www\Office_management_system\system\libraries\Session\Session.php 137
ERROR - 2026-06-24 05:16:42 --> Severity: 8192 --> Creation of dynamic property Calls::$session is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 1284
ERROR - 2026-06-24 05:16:42 --> Severity: 8192 --> Creation of dynamic property Calls::$Call_model is deprecated C:\wamp64\www\Office_management_system\system\core\Loader.php 359
ERROR - 2026-06-24 05:16:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\Office_management_system\system\core\Exceptions.php:76) C:\wamp64\www\Office_management_system\system\helpers\url_helper.php 565
