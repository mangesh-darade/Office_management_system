<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-07-09 04:51:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\wamp64\www\Office_management_system\system\database\drivers\mysqli\mysqli_driver.php 212
ERROR - 2026-07-09 04:51:59 --> Unable to connect to the database
ERROR - 2026-07-09 10:29:14 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:27:14'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:29:16 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:27:16'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:29:18 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:27:18'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:29:21 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:27:21'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:29:25 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:27:25'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:29:28 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:27:28'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:29:31 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:27:31'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:29:34 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:27:34'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:29:37 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:27:37'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:29:40 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:27:40'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 04:59:43 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'admin_stadmin_internal_portal' C:\wamp64\www\Office_management_system\system\database\drivers\mysqli\mysqli_driver.php 212
ERROR - 2026-07-09 04:59:43 --> Unable to connect to the database
ERROR - 2026-07-09 04:59:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'admin_stadmin_internal_portal' C:\wamp64\www\Office_management_system\system\database\drivers\mysqli\mysqli_driver.php 212
ERROR - 2026-07-09 04:59:46 --> Unable to connect to the database
ERROR - 2026-07-09 04:59:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'admin_stadmin_internal_portal' C:\wamp64\www\Office_management_system\system\database\drivers\mysqli\mysqli_driver.php 212
ERROR - 2026-07-09 04:59:49 --> Unable to connect to the database
ERROR - 2026-07-09 10:29:52 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:27:52'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:29:55 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:27:55'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:29:58 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:27:58'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:30:01 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:28:01'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:30:04 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:28:04'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:30:07 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:28:07'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:30:10 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:28:10'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:30:13 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:28:13'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:30:16 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:28:16'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:30:19 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:28:19'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:30:32 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:28:32'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:31:01 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:29:01'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:31:04 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:29:04'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:31:07 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:29:07'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:31:10 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:29:10'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:31:13 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:29:13'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:31:16 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:29:16'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:31:19 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:29:19'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:31:22 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:29:22'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:31:25 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:29:25'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:31:28 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:29:28'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:31:31 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:29:31'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:31:34 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:29:34'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:31:37 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:29:37'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:31:40 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:29:40'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:31:43 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:29:43'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:31:46 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:29:46'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:31:49 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:29:49'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:31:52 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:29:52'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:31:55 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:29:55'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:31:58 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:29:58'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:32:01 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:30:01'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:32:32 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:30:32'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:33:32 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:31:32'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:34:32 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:32:32'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:35:32 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:33:32'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:36:32 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:34:32'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:37:32 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:35:32'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:38:32 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:36:32'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:39:32 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:37:32'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:40:32 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:38:32'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 10:41:32 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 10:39:32'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 11:07:30 --> Severity: Warning --> Undefined variable $outType C:\wamp64\www\Office_management_system\application\controllers\Attendance.php 519
ERROR - 2026-07-09 11:39:33 --> 404 Page Not Found: 
ERROR - 2026-07-09 11:39:39 --> 404 Page Not Found: 
ERROR - 2026-07-09 11:40:28 --> 404 Page Not Found: 
ERROR - 2026-07-09 11:43:17 --> 404 Page Not Found: 
ERROR - 2026-07-09 11:45:55 --> 404 Page Not Found: 
ERROR - 2026-07-09 12:03:32 --> Query error: Duplicate entry '0' for key 'notifications.PRIMARY' - Invalid query: INSERT INTO `notifications` (`user_id`, `title`, `message`, `type`, `module`, `related_id`, `action_url`, `is_read`, `is_deleted`, `created_at`) VALUES (8, '+100 points approved', 'Contribution for Office Related Activities', 'success', 'rewards', 697, 'http://localhost/Office_management_system/spl/dashboard?tab=my-reward', 0, 0, '2026-07-09 12:03:32')
ERROR - 2026-07-09 12:03:37 --> 404 Page Not Found: 
ERROR - 2026-07-09 12:03:48 --> Query error: Duplicate entry '0' for key 'notifications.PRIMARY' - Invalid query: INSERT INTO `notifications` (`user_id`, `title`, `message`, `type`, `module`, `related_id`, `action_url`, `is_read`, `is_deleted`, `created_at`) VALUES (13, '+100 points approved', 'Contribution for Office Related Activities', 'success', 'rewards', 696, 'http://localhost/Office_management_system/spl/dashboard?tab=my-reward', 0, 0, '2026-07-09 12:03:48')
ERROR - 2026-07-09 12:06:25 --> Query error: Duplicate entry '0' for key 'notifications.PRIMARY' - Invalid query: INSERT INTO `notifications` (`user_id`, `title`, `message`, `type`, `module`, `related_id`, `action_url`, `is_read`, `is_deleted`, `created_at`) VALUES (1, '+100 points approved', 'CSR / Social Initiative Participation', 'success', 'rewards', NULL, 'http://localhost/Office_management_system/spl/dashboard?tab=my-reward', 0, 0, '2026-07-09 12:06:25')
ERROR - 2026-07-09 12:09:22 --> 404 Page Not Found: 
ERROR - 2026-07-09 12:10:47 --> Query error: Duplicate entry '0' for key 'reward_transactions.PRIMARY' - Invalid query: INSERT INTO `reward_transactions` (`user_id`, `rule_id`, `category_id`, `points`, `status`, `source_module`, `source_record_id`, `source_event`, `idempotency_key`, `reference_label`, `granted_by`, `period_key`, `created_at`) VALUES (1, 26, 5, 20, 'pending', 'spl', NULL, 'reward_claim', '72a679b2948425502f3f501edab9fd1eada4252c', '<p>asdasdasdad</p>', 1, '2026-07', '2026-07-09 12:10:47')
ERROR - 2026-07-09 06:43:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'admin_stadmin_internal_portal' C:\wamp64\www\Office_management_system\system\database\drivers\mysqli\mysqli_driver.php 212
ERROR - 2026-07-09 06:43:13 --> Unable to connect to the database
ERROR - 2026-07-09 06:43:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'admin_stadmin_internal_portal' C:\wamp64\www\Office_management_system\system\database\drivers\mysqli\mysqli_driver.php 212
ERROR - 2026-07-09 06:43:16 --> Unable to connect to the database
ERROR - 2026-07-09 06:43:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'admin_stadmin_internal_portal' C:\wamp64\www\Office_management_system\system\database\drivers\mysqli\mysqli_driver.php 212
ERROR - 2026-07-09 06:43:19 --> Unable to connect to the database
ERROR - 2026-07-09 06:43:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'admin_stadmin_internal_portal' C:\wamp64\www\Office_management_system\system\database\drivers\mysqli\mysqli_driver.php 212
ERROR - 2026-07-09 06:43:22 --> Unable to connect to the database
ERROR - 2026-07-09 06:43:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'admin_stadmin_internal_portal' C:\wamp64\www\Office_management_system\system\database\drivers\mysqli\mysqli_driver.php 212
ERROR - 2026-07-09 06:43:25 --> Unable to connect to the database
ERROR - 2026-07-09 06:43:28 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'admin_stadmin_internal_portal' C:\wamp64\www\Office_management_system\system\database\drivers\mysqli\mysqli_driver.php 212
ERROR - 2026-07-09 06:43:28 --> Unable to connect to the database
ERROR - 2026-07-09 06:43:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'admin_stadmin_internal_portal' C:\wamp64\www\Office_management_system\system\database\drivers\mysqli\mysqli_driver.php 212
ERROR - 2026-07-09 06:43:31 --> Unable to connect to the database
ERROR - 2026-07-09 06:43:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'admin_stadmin_internal_portal' C:\wamp64\www\Office_management_system\system\database\drivers\mysqli\mysqli_driver.php 212
ERROR - 2026-07-09 06:43:34 --> Unable to connect to the database
ERROR - 2026-07-09 06:43:37 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'admin_stadmin_internal_portal' C:\wamp64\www\Office_management_system\system\database\drivers\mysqli\mysqli_driver.php 212
ERROR - 2026-07-09 06:43:37 --> Unable to connect to the database
ERROR - 2026-07-09 06:43:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'admin_stadmin_internal_portal' C:\wamp64\www\Office_management_system\system\database\drivers\mysqli\mysqli_driver.php 212
ERROR - 2026-07-09 06:43:40 --> Unable to connect to the database
ERROR - 2026-07-09 06:43:43 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'admin_stadmin_internal_portal' C:\wamp64\www\Office_management_system\system\database\drivers\mysqli\mysqli_driver.php 212
ERROR - 2026-07-09 06:43:43 --> Unable to connect to the database
ERROR - 2026-07-09 12:13:45 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 12:11:45'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 12:13:47 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT q.*, u.name AS recipient_name, s.name AS submitter_name, r.name AS rule_name, r.code AS rule_code, r.points AS rule_points, c.name AS category_name, t.reference_label
FROM `reward_approval_queue` `q`
LEFT JOIN `users` `u` ON `u`.`id` = `q`.`user_id`
LEFT JOIN `users` `s` ON `s`.`id` = `q`.`submitted_by`
LEFT JOIN `reward_rules` `r` ON `r`.`id` = `q`.`rule_id`
LEFT JOIN `reward_categories` `c` ON `c`.`id` = `r`.`category_id`
LEFT JOIN `reward_transactions` `t` ON `t`.`id` = `q`.`transaction_id`
WHERE `q`.`status` = 'pending'
AND `q`.`source_module` = 'spl'
ORDER BY `q`.`submitted_at` DESC
 LIMIT 20
ERROR - 2026-07-09 12:13:52 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT t.*, r.name AS rule_name, COALESCE(c.name, rc.name) AS category_name, u.name AS user_name
FROM `reward_transactions` `t`
LEFT JOIN `reward_rules` `r` ON `r`.`id` = `t`.`rule_id`
LEFT JOIN `reward_categories` `c` ON `c`.`id` = `t`.`category_id`
LEFT JOIN `reward_categories` `rc` ON `rc`.`id` = `r`.`category_id`
LEFT JOIN `users` `u` ON `u`.`id` = `t`.`user_id`
WHERE `t`.`status` IN('approved', 'pending')
AND DATE(t.created_at) >= '2026-07-06'
AND DATE(t.created_at) <= '2026-07-09'
ORDER BY `t`.`created_at` DESC, `t`.`id` DESC
 LIMIT 20
ERROR - 2026-07-09 12:13:56 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 12:11:56'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 12:13:59 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 12:11:59'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 12:13:59 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT w.*, cb.name AS created_by_name, cb.email AS created_by_email, cf.name AS created_for_name, cf.email AS created_for_email
FROM `my_works` `w`
LEFT JOIN `users` `cb` ON `cb`.`id` = `w`.`created_by`
LEFT JOIN `users` `cf` ON `cf`.`id` = `w`.`created_for`
ORDER BY `w`.`is_urgent` DESC, `w`.`is_important` DESC, `w`.`due_date` ASC, `w`.`updated_at` DESC, `w`.`id` DESC
 LIMIT 2000
ERROR - 2026-07-09 12:13:59 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT t.*, r.name AS rule_name, COALESCE(c.name, rc.name) AS category_name, u.name AS user_name
FROM `reward_transactions` `t`
LEFT JOIN `reward_rules` `r` ON `r`.`id` = `t`.`rule_id`
LEFT JOIN `reward_categories` `c` ON `c`.`id` = `t`.`category_id`
LEFT JOIN `reward_categories` `rc` ON `rc`.`id` = `r`.`category_id`
LEFT JOIN `users` `u` ON `u`.`id` = `t`.`user_id`
WHERE `t`.`status` IN('approved', 'pending')
AND DATE(t.created_at) >= '2026-07-06'
AND DATE(t.created_at) <= '2026-07-09'
ORDER BY `t`.`created_at` DESC, `t`.`id` DESC
 LIMIT 20
ERROR - 2026-07-09 12:14:02 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 12:12:02'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 12:14:02 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT w.*, cb.name AS created_by_name, cb.email AS created_by_email, cf.name AS created_for_name, cf.email AS created_for_email
FROM `my_works` `w`
LEFT JOIN `users` `cb` ON `cb`.`id` = `w`.`created_by`
LEFT JOIN `users` `cf` ON `cf`.`id` = `w`.`created_for`
ORDER BY `w`.`is_urgent` DESC, `w`.`is_important` DESC, `w`.`due_date` ASC, `w`.`updated_at` DESC, `w`.`id` DESC
 LIMIT 2000
ERROR - 2026-07-09 12:14:04 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 12:12:04'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 12:14:04 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 12:12:04'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 12:14:05 --> Query error: Table 'admin_stadmin_internal_portal.attendance' doesn't exist - Invalid query: SELECT *
FROM `attendance`
WHERE `user_id` = 1
AND `date` = '2026-07-09'
ERROR - 2026-07-09 12:14:07 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 12:12:07'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 12:14:08 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 12:12:08'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 12:14:08 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT w.*, cb.name AS created_by_name, cb.email AS created_by_email, cf.name AS created_for_name, cf.email AS created_for_email
FROM `my_works` `w`
LEFT JOIN `users` `cb` ON `cb`.`id` = `w`.`created_by`
LEFT JOIN `users` `cf` ON `cf`.`id` = `w`.`created_for`
ORDER BY `w`.`is_urgent` DESC, `w`.`is_important` DESC, `w`.`due_date` ASC, `w`.`updated_at` DESC, `w`.`id` DESC
 LIMIT 2000
ERROR - 2026-07-09 12:14:10 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT t.*, r.name AS rule_name, COALESCE(c.name, rc.name) AS category_name, u.name AS user_name
FROM `reward_transactions` `t`
LEFT JOIN `reward_rules` `r` ON `r`.`id` = `t`.`rule_id`
LEFT JOIN `reward_categories` `c` ON `c`.`id` = `t`.`category_id`
LEFT JOIN `reward_categories` `rc` ON `rc`.`id` = `r`.`category_id`
LEFT JOIN `users` `u` ON `u`.`id` = `t`.`user_id`
WHERE `t`.`status` IN('approved', 'pending')
AND DATE(t.created_at) >= '2026-07-06'
AND DATE(t.created_at) <= '2026-07-09'
ORDER BY `t`.`created_at` DESC, `t`.`id` DESC
 LIMIT 20
ERROR - 2026-07-09 12:20:44 --> Query error: Table 'roles' already exists - Invalid query: CREATE TABLE `roles` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `name` varchar(100) NOT NULL,
                `group_type` varchar(50) DEFAULT NULL,
                `is_active` tinyint(1) NOT NULL DEFAULT '1',
                `sort_order` int(11) NOT NULL DEFAULT '0',
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8
ERROR - 2026-07-09 12:20:48 --> Query error: Table 'api_integrations' already exists - Invalid query: CREATE TABLE `api_integrations` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `service_type` varchar(50) NOT NULL COMMENT 'sendgrid, whatsapp, smtp',
                `service_name` varchar(100) NOT NULL,
                `account_id` varchar(255) DEFAULT NULL COMMENT 'Account SID, API Key, etc.',
                `auth_token` text DEFAULT NULL COMMENT 'Auth Token, API Secret, Password',
                `from_email` varchar(255) DEFAULT NULL COMMENT 'For email services',
                `from_name` varchar(255) DEFAULT NULL COMMENT 'For email services',
                `from_number` varchar(50) DEFAULT NULL COMMENT 'For WhatsApp/SMS',
                `content_sid` varchar(255) DEFAULT NULL COMMENT 'Twilio Content Template SID',
                `is_active` tinyint(1) DEFAULT 1,
                `is_default` tinyint(1) DEFAULT 0 COMMENT 'Default service for this type',
                `notes` text DEFAULT NULL,
                `created_at` datetime DEFAULT NULL,
                `updated_at` datetime DEFAULT NULL,
                PRIMARY KEY (`id`),
                KEY `idx_service_type` (`service_type`),
                KEY `idx_is_active` (`is_active`),
                KEY `idx_is_default` (`is_default`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8
ERROR - 2026-07-09 12:20:51 --> Query error: Duplicate column name 'created_by' - Invalid query: ALTER TABLE `api_integrations` ADD `created_by` int(11) DEFAULT NULL
ERROR - 2026-07-09 12:20:55 --> Query error: Table 'shifts' already exists - Invalid query: CREATE TABLE `shifts` (
                    `id` int(11) NOT NULL AUTO_INCREMENT,
                    `name` varchar(100) NOT NULL,
                    `start_time` time NOT NULL,
                    `end_time` time NOT NULL,
                    `late_grace_period` int(11) DEFAULT 15 COMMENT 'Minutes allowed after start time',
                    `early_exit_grace_period` int(11) DEFAULT 0 COMMENT 'Minutes allowed before end time',
                    `is_active` tinyint(1) DEFAULT 1,
                    `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
                    `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    PRIMARY KEY (`id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
ERROR - 2026-07-09 12:21:06 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE   (
`email` = '7744010738'
 )
ERROR - 2026-07-09 12:21:08 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE   (
`email` = '7744010738'
 )
ERROR - 2026-07-09 12:21:09 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE   (
`email` = '7744010738'
 )
ERROR - 2026-07-09 12:21:09 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE   (
`email` = '7744010738'
 )
ERROR - 2026-07-09 12:21:09 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE   (
`email` = '7744010738'
 )
ERROR - 2026-07-09 12:21:10 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE   (
`email` = '7744010738'
 )
ERROR - 2026-07-09 12:21:10 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE   (
`email` = '7744010738'
 )
ERROR - 2026-07-09 12:21:10 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE   (
`email` = '7744010738'
 )
ERROR - 2026-07-09 12:21:10 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE   (
`email` = '7744010738'
 )
ERROR - 2026-07-09 12:21:10 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE   (
`email` = '7744010738'
 )
ERROR - 2026-07-09 12:21:11 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE   (
`email` = '7744010738'
 )
ERROR - 2026-07-09 12:23:16 --> Query error: Table 'assets' already exists - Invalid query: CREATE TABLE `assets` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `name` varchar(190) NOT NULL,
                `category` varchar(100) DEFAULT NULL,
                `brand` varchar(100) DEFAULT NULL,
                `model` varchar(100) DEFAULT NULL,
                `serial_no` varchar(190) DEFAULT NULL,
                `asset_tag` varchar(100) DEFAULT NULL,
                `ram` varchar(50) DEFAULT NULL,
                `hdd` varchar(50) DEFAULT NULL,
                `status` varchar(20) NOT NULL DEFAULT 'in_stock',
                `purchased_on` date DEFAULT NULL,
                `notes` text,
                `created_at` datetime DEFAULT NULL,
                `updated_at` datetime DEFAULT NULL,
                PRIMARY KEY (`id`),
                KEY `idx_status` (`status`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8
ERROR - 2026-07-09 12:23:22 --> Query error: Table 'lead_user_mapping' already exists - Invalid query: CREATE TABLE `lead_user_mapping` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `lead_id` int(11) NOT NULL,
                `user_id` int(11) NOT NULL,
                `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                UNIQUE KEY `uq_lead_user` (`lead_id`,`user_id`),
                KEY `idx_lead` (`lead_id`),
                KEY `idx_user` (`user_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8
ERROR - 2026-07-09 12:24:33 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE   (
`email` = '7744010738'
 )
ERROR - 2026-07-09 12:24:35 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE   (
`email` = '7744010738'
 )
ERROR - 2026-07-09 12:24:36 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE   (
`email` = '7744010738'
 )
ERROR - 2026-07-09 12:24:37 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE   (
`email` = '7744010738'
 )
ERROR - 2026-07-09 12:24:37 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE   (
`email` = '7744010738'
 )
ERROR - 2026-07-09 12:24:37 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE   (
`email` = '7744010738'
 )
ERROR - 2026-07-09 12:24:37 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE   (
`email` = '7744010738'
 )
ERROR - 2026-07-09 12:25:24 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE   (
`email` = '7744010738'
 )
ERROR - 2026-07-09 12:25:40 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE   (
`email` = '7744010738'
 )
ERROR - 2026-07-09 12:26:36 --> Query error: Table 'roles' already exists - Invalid query: CREATE TABLE `roles` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `name` varchar(100) NOT NULL,
                `group_type` varchar(50) DEFAULT NULL,
                `is_active` tinyint(1) NOT NULL DEFAULT '1',
                `sort_order` int(11) NOT NULL DEFAULT '0',
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8
ERROR - 2026-07-09 12:26:42 --> Query error: Table 'settings' already exists - Invalid query: CREATE TABLE `settings` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `key` varchar(190) NOT NULL,
                `value` text NULL,
                PRIMARY KEY (`id`),
                UNIQUE KEY `uq_setting_key` (`key`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8
ERROR - 2026-07-09 12:26:44 --> Query error: Table 'api_integrations' already exists - Invalid query: CREATE TABLE `api_integrations` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `service_type` varchar(50) NOT NULL COMMENT 'sendgrid, whatsapp, smtp',
                `service_name` varchar(100) NOT NULL,
                `account_id` varchar(255) DEFAULT NULL COMMENT 'Account SID, API Key, etc.',
                `auth_token` text DEFAULT NULL COMMENT 'Auth Token, API Secret, Password',
                `from_email` varchar(255) DEFAULT NULL COMMENT 'For email services',
                `from_name` varchar(255) DEFAULT NULL COMMENT 'For email services',
                `from_number` varchar(50) DEFAULT NULL COMMENT 'For WhatsApp/SMS',
                `content_sid` varchar(255) DEFAULT NULL COMMENT 'Twilio Content Template SID',
                `is_active` tinyint(1) DEFAULT 1,
                `is_default` tinyint(1) DEFAULT 0 COMMENT 'Default service for this type',
                `notes` text DEFAULT NULL,
                `created_at` datetime DEFAULT NULL,
                `updated_at` datetime DEFAULT NULL,
                PRIMARY KEY (`id`),
                KEY `idx_service_type` (`service_type`),
                KEY `idx_is_active` (`is_active`),
                KEY `idx_is_default` (`is_default`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8
ERROR - 2026-07-09 12:26:45 --> Query error: Duplicate column name 'created_by' - Invalid query: ALTER TABLE `api_integrations` ADD `created_by` int(11) DEFAULT NULL
ERROR - 2026-07-09 12:26:46 --> Query error: Table 'shifts' already exists - Invalid query: CREATE TABLE `shifts` (
                    `id` int(11) NOT NULL AUTO_INCREMENT,
                    `name` varchar(100) NOT NULL,
                    `start_time` time NOT NULL,
                    `end_time` time NOT NULL,
                    `late_grace_period` int(11) DEFAULT 15 COMMENT 'Minutes allowed after start time',
                    `early_exit_grace_period` int(11) DEFAULT 0 COMMENT 'Minutes allowed before end time',
                    `is_active` tinyint(1) DEFAULT 1,
                    `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
                    `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    PRIMARY KEY (`id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
ERROR - 2026-07-09 12:26:48 --> Query error: Table 'assets' already exists - Invalid query: CREATE TABLE `assets` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `name` varchar(190) NOT NULL,
                `category` varchar(100) DEFAULT NULL,
                `brand` varchar(100) DEFAULT NULL,
                `model` varchar(100) DEFAULT NULL,
                `serial_no` varchar(190) DEFAULT NULL,
                `asset_tag` varchar(100) DEFAULT NULL,
                `ram` varchar(50) DEFAULT NULL,
                `hdd` varchar(50) DEFAULT NULL,
                `status` varchar(20) NOT NULL DEFAULT 'in_stock',
                `purchased_on` date DEFAULT NULL,
                `notes` text,
                `created_at` datetime DEFAULT NULL,
                `updated_at` datetime DEFAULT NULL,
                PRIMARY KEY (`id`),
                KEY `idx_status` (`status`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8
ERROR - 2026-07-09 12:26:49 --> Query error: Table 'module_types' already exists - Invalid query: CREATE TABLE `module_types` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `name` varchar(100) NOT NULL,
                `code` varchar(50) NOT NULL,
                `module` varchar(50) NOT NULL COMMENT 'my_works, clients, projects, requirements, employees',
                `display_order` int(11) DEFAULT 0,
                `is_active` tinyint(1) DEFAULT 1,
                `description` text DEFAULT NULL,
                `created_at` datetime DEFAULT NULL,
                `updated_at` datetime DEFAULT NULL,
                PRIMARY KEY (`id`),
                UNIQUE KEY `uq_module_type_code` (`code`, `module`),
                KEY `idx_module_types_module` (`module`),
                KEY `idx_module_types_active` (`is_active`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
ERROR - 2026-07-09 12:26:49 --> Query error: Table 'lead_user_mapping' already exists - Invalid query: CREATE TABLE `lead_user_mapping` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `lead_id` int(11) NOT NULL,
                `user_id` int(11) NOT NULL,
                `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                UNIQUE KEY `uq_lead_user` (`lead_id`,`user_id`),
                KEY `idx_lead` (`lead_id`),
                KEY `idx_user` (`user_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8
ERROR - 2026-07-09 12:26:51 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 12:24:51'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 12:26:51 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 12:24:51'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 12:26:51 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 12:24:51'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 12:26:51 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 12:24:51'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 12:26:53 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 12:24:53'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 12:26:54 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-09 12:24:54'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-09 12:26:54 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT w.*, cb.name AS created_by_name, cb.email AS created_by_email, cf.name AS created_for_name, cf.email AS created_for_email, cl.company_name AS client_name
FROM `my_works` `w`
LEFT JOIN `users` `cb` ON `cb`.`id` = `w`.`created_by`
LEFT JOIN `users` `cf` ON `cf`.`id` = `w`.`created_for`
LEFT JOIN `clients` `cl` ON `cl`.`id` = `w`.`client_id`
ORDER BY `w`.`is_urgent` DESC, `w`.`is_important` DESC, `w`.`due_date` ASC, `w`.`updated_at` DESC, `w`.`id` DESC
 LIMIT 2000
ERROR - 2026-07-09 12:26:55 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT t.*, r.name AS rule_name, COALESCE(c.name, rc.name) AS category_name, u.name AS user_name
FROM `reward_transactions` `t`
LEFT JOIN `reward_rules` `r` ON `r`.`id` = `t`.`rule_id`
LEFT JOIN `reward_categories` `c` ON `c`.`id` = `t`.`category_id`
LEFT JOIN `reward_categories` `rc` ON `rc`.`id` = `r`.`category_id`
LEFT JOIN `users` `u` ON `u`.`id` = `t`.`user_id`
WHERE `t`.`status` IN('approved', 'pending')
AND DATE(t.created_at) >= '2026-07-06'
AND DATE(t.created_at) <= '2026-07-09'
ORDER BY `t`.`created_at` DESC, `t`.`id` DESC
 LIMIT 20
ERROR - 2026-07-09 12:26:57 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT t.*, r.name AS rule_name, COALESCE(c.name, rc.name) AS category_name, u.name AS user_name
FROM `reward_transactions` `t`
LEFT JOIN `reward_rules` `r` ON `r`.`id` = `t`.`rule_id`
LEFT JOIN `reward_categories` `c` ON `c`.`id` = `t`.`category_id`
LEFT JOIN `reward_categories` `rc` ON `rc`.`id` = `r`.`category_id`
LEFT JOIN `users` `u` ON `u`.`id` = `t`.`user_id`
WHERE `t`.`status` IN('approved', 'pending')
AND DATE(t.created_at) >= '2026-07-06'
AND DATE(t.created_at) <= '2026-07-09'
ORDER BY `t`.`created_at` DESC, `t`.`id` DESC
 LIMIT 20
ERROR - 2026-07-09 12:26:58 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT t.*, r.name AS rule_name, COALESCE(c.name, rc.name) AS category_name, u.name AS user_name
FROM `reward_transactions` `t`
LEFT JOIN `reward_rules` `r` ON `r`.`id` = `t`.`rule_id`
LEFT JOIN `reward_categories` `c` ON `c`.`id` = `t`.`category_id`
LEFT JOIN `reward_categories` `rc` ON `rc`.`id` = `r`.`category_id`
LEFT JOIN `users` `u` ON `u`.`id` = `t`.`user_id`
WHERE `t`.`status` IN('approved', 'pending')
AND DATE(t.created_at) >= '2026-07-06'
AND DATE(t.created_at) <= '2026-07-09'
ORDER BY `t`.`created_at` DESC, `t`.`id` DESC
 LIMIT 20
ERROR - 2026-07-09 12:26:58 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT t.*, r.name AS rule_name, COALESCE(c.name, rc.name) AS category_name, u.name AS user_name
FROM `reward_transactions` `t`
LEFT JOIN `reward_rules` `r` ON `r`.`id` = `t`.`rule_id`
LEFT JOIN `reward_categories` `c` ON `c`.`id` = `t`.`category_id`
LEFT JOIN `reward_categories` `rc` ON `rc`.`id` = `r`.`category_id`
LEFT JOIN `users` `u` ON `u`.`id` = `t`.`user_id`
WHERE `t`.`status` IN('approved', 'pending')
AND DATE(t.created_at) >= '2026-07-06'
AND DATE(t.created_at) <= '2026-07-09'
ORDER BY `t`.`created_at` DESC, `t`.`id` DESC
 LIMIT 20
ERROR - 2026-07-09 12:26:59 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT t.*, r.name AS rule_name, COALESCE(c.name, rc.name) AS category_name, u.name AS user_name
FROM `reward_transactions` `t`
LEFT JOIN `reward_rules` `r` ON `r`.`id` = `t`.`rule_id`
LEFT JOIN `reward_categories` `c` ON `c`.`id` = `t`.`category_id`
LEFT JOIN `reward_categories` `rc` ON `rc`.`id` = `r`.`category_id`
LEFT JOIN `users` `u` ON `u`.`id` = `t`.`user_id`
WHERE `t`.`status` IN('approved', 'pending')
AND DATE(t.created_at) >= '2026-07-06'
AND DATE(t.created_at) <= '2026-07-09'
ORDER BY `t`.`created_at` DESC, `t`.`id` DESC
 LIMIT 20
ERROR - 2026-07-09 12:26:59 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT t.*, r.name AS rule_name, COALESCE(c.name, rc.name) AS category_name, u.name AS user_name
FROM `reward_transactions` `t`
LEFT JOIN `reward_rules` `r` ON `r`.`id` = `t`.`rule_id`
LEFT JOIN `reward_categories` `c` ON `c`.`id` = `t`.`category_id`
LEFT JOIN `reward_categories` `rc` ON `rc`.`id` = `r`.`category_id`
LEFT JOIN `users` `u` ON `u`.`id` = `t`.`user_id`
WHERE `t`.`status` IN('approved', 'pending')
AND DATE(t.created_at) >= '2026-07-06'
AND DATE(t.created_at) <= '2026-07-09'
ORDER BY `t`.`created_at` DESC, `t`.`id` DESC
 LIMIT 20
ERROR - 2026-07-09 12:26:59 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT t.*, r.name AS rule_name, COALESCE(c.name, rc.name) AS category_name, u.name AS user_name
FROM `reward_transactions` `t`
LEFT JOIN `reward_rules` `r` ON `r`.`id` = `t`.`rule_id`
LEFT JOIN `reward_categories` `c` ON `c`.`id` = `t`.`category_id`
LEFT JOIN `reward_categories` `rc` ON `rc`.`id` = `r`.`category_id`
LEFT JOIN `users` `u` ON `u`.`id` = `t`.`user_id`
WHERE `t`.`status` IN('approved', 'pending')
AND DATE(t.created_at) >= '2026-07-06'
AND DATE(t.created_at) <= '2026-07-09'
ORDER BY `t`.`created_at` DESC, `t`.`id` DESC
 LIMIT 20
ERROR - 2026-07-09 12:28:40 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT t.*, r.name AS rule_name, COALESCE(c.name, rc.name) AS category_name, u.name AS user_name
FROM `reward_transactions` `t`
LEFT JOIN `reward_rules` `r` ON `r`.`id` = `t`.`rule_id`
LEFT JOIN `reward_categories` `c` ON `c`.`id` = `t`.`category_id`
LEFT JOIN `reward_categories` `rc` ON `rc`.`id` = `r`.`category_id`
LEFT JOIN `users` `u` ON `u`.`id` = `t`.`user_id`
WHERE `t`.`status` IN('approved', 'pending')
AND DATE(t.created_at) >= '2026-07-06'
AND DATE(t.created_at) <= '2026-07-09'
ORDER BY `t`.`created_at` DESC, `t`.`id` DESC
 LIMIT 20
ERROR - 2026-07-09 12:28:41 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT t.*, r.name AS rule_name, COALESCE(c.name, rc.name) AS category_name, u.name AS user_name
FROM `reward_transactions` `t`
LEFT JOIN `reward_rules` `r` ON `r`.`id` = `t`.`rule_id`
LEFT JOIN `reward_categories` `c` ON `c`.`id` = `t`.`category_id`
LEFT JOIN `reward_categories` `rc` ON `rc`.`id` = `r`.`category_id`
LEFT JOIN `users` `u` ON `u`.`id` = `t`.`user_id`
WHERE `t`.`status` IN('approved', 'pending')
AND DATE(t.created_at) >= '2026-07-06'
AND DATE(t.created_at) <= '2026-07-09'
ORDER BY `t`.`created_at` DESC, `t`.`id` DESC
 LIMIT 20
ERROR - 2026-07-09 12:28:41 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT t.*, r.name AS rule_name, COALESCE(c.name, rc.name) AS category_name, u.name AS user_name
FROM `reward_transactions` `t`
LEFT JOIN `reward_rules` `r` ON `r`.`id` = `t`.`rule_id`
LEFT JOIN `reward_categories` `c` ON `c`.`id` = `t`.`category_id`
LEFT JOIN `reward_categories` `rc` ON `rc`.`id` = `r`.`category_id`
LEFT JOIN `users` `u` ON `u`.`id` = `t`.`user_id`
WHERE `t`.`status` IN('approved', 'pending')
AND DATE(t.created_at) >= '2026-07-06'
AND DATE(t.created_at) <= '2026-07-09'
ORDER BY `t`.`created_at` DESC, `t`.`id` DESC
 LIMIT 20
ERROR - 2026-07-09 12:28:42 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT t.*, r.name AS rule_name, COALESCE(c.name, rc.name) AS category_name, u.name AS user_name
FROM `reward_transactions` `t`
LEFT JOIN `reward_rules` `r` ON `r`.`id` = `t`.`rule_id`
LEFT JOIN `reward_categories` `c` ON `c`.`id` = `t`.`category_id`
LEFT JOIN `reward_categories` `rc` ON `rc`.`id` = `r`.`category_id`
LEFT JOIN `users` `u` ON `u`.`id` = `t`.`user_id`
WHERE `t`.`status` IN('approved', 'pending')
AND DATE(t.created_at) >= '2026-07-06'
AND DATE(t.created_at) <= '2026-07-09'
ORDER BY `t`.`created_at` DESC, `t`.`id` DESC
 LIMIT 20
ERROR - 2026-07-09 12:28:42 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT t.*, r.name AS rule_name, COALESCE(c.name, rc.name) AS category_name, u.name AS user_name
FROM `reward_transactions` `t`
LEFT JOIN `reward_rules` `r` ON `r`.`id` = `t`.`rule_id`
LEFT JOIN `reward_categories` `c` ON `c`.`id` = `t`.`category_id`
LEFT JOIN `reward_categories` `rc` ON `rc`.`id` = `r`.`category_id`
LEFT JOIN `users` `u` ON `u`.`id` = `t`.`user_id`
WHERE `t`.`status` IN('approved', 'pending')
AND DATE(t.created_at) >= '2026-07-06'
AND DATE(t.created_at) <= '2026-07-09'
ORDER BY `t`.`created_at` DESC, `t`.`id` DESC
 LIMIT 20
ERROR - 2026-07-09 12:29:13 --> Query error: Table 'api_integrations' already exists - Invalid query: CREATE TABLE `api_integrations` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `service_type` varchar(50) NOT NULL COMMENT 'sendgrid, whatsapp, smtp',
                `service_name` varchar(100) NOT NULL,
                `account_id` varchar(255) DEFAULT NULL COMMENT 'Account SID, API Key, etc.',
                `auth_token` text DEFAULT NULL COMMENT 'Auth Token, API Secret, Password',
                `from_email` varchar(255) DEFAULT NULL COMMENT 'For email services',
                `from_name` varchar(255) DEFAULT NULL COMMENT 'For email services',
                `from_number` varchar(50) DEFAULT NULL COMMENT 'For WhatsApp/SMS',
                `content_sid` varchar(255) DEFAULT NULL COMMENT 'Twilio Content Template SID',
                `is_active` tinyint(1) DEFAULT 1,
                `is_default` tinyint(1) DEFAULT 0 COMMENT 'Default service for this type',
                `notes` text DEFAULT NULL,
                `created_at` datetime DEFAULT NULL,
                `updated_at` datetime DEFAULT NULL,
                PRIMARY KEY (`id`),
                KEY `idx_service_type` (`service_type`),
                KEY `idx_is_active` (`is_active`),
                KEY `idx_is_default` (`is_default`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8
ERROR - 2026-07-09 13:24:02 --> Severity: Warning --> Undefined variable $outType C:\wamp64\www\Office_management_system\application\controllers\Attendance.php 519
