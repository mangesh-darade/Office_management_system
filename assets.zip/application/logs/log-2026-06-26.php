<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-06-26 05:39:17 --> Query error: Duplicate column name 'code' - Invalid query: ALTER TABLE `subscription_builder_countries` ADD `code` varchar(10) NOT NULL DEFAULT '' AFTER `name`
ERROR - 2026-06-26 15:19:58 --> Severity: error --> Exception: Call to undefined function subscription_builder_quote_render_export_html() C:\wamp64\www\Office_management_system\application\controllers\Subscription_builder.php 200
ERROR - 2026-06-26 15:20:03 --> Severity: error --> Exception: Call to undefined function subscription_builder_quote_render_export_html() C:\wamp64\www\Office_management_system\application\controllers\Subscription_builder.php 200
ERROR - 2026-06-26 15:28:50 --> subscription_builder_quote_save_pdf: Dompdf could not render proposal HTML.
ERROR - 2026-06-26 15:28:57 --> subscription_builder_quote_save_pdf: Dompdf could not render proposal HTML.
ERROR - 2026-06-26 15:33:42 --> subscription_builder_quote_save_pdf: Dompdf could not render proposal HTML.
ERROR - 2026-06-26 15:36:44 --> subscription_builder_quote_save_pdf: Dompdf could not render proposal HTML.
ERROR - 2026-06-26 15:39:02 --> subscription_builder_quote_save_pdf: Dompdf could not render proposal HTML.
