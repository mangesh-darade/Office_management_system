<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-07-10 09:43:02 --> Query error: Column 'project_id' cannot be null - Invalid query: INSERT INTO `tasks` (`project_id`, `title`, `description`, `assigned_to`, `status`, `created_by`, `priority`, `start_date`, `due_date`, `reference_url`) VALUES (NULL, 'GA4 setup', '', 32, 'pending', 1, 'medium', NULL, NULL, NULL)
ERROR - 2026-07-10 04:33:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'admin_stadmin_internal_portal' C:\wamp64\www\Office_management_system\system\database\drivers\mysqli\mysqli_driver.php 212
ERROR - 2026-07-10 04:33:07 --> Unable to connect to the database
ERROR - 2026-07-10 04:33:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'admin_stadmin_internal_portal' C:\wamp64\www\Office_management_system\system\database\drivers\mysqli\mysqli_driver.php 212
ERROR - 2026-07-10 04:33:10 --> Unable to connect to the database
ERROR - 2026-07-10 10:03:13 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-10 10:01:13'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-10 10:03:16 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-10 10:01:16'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-10 10:03:19 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-10 10:01:19'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-10 10:03:22 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-10 10:01:22'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-10 10:03:25 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-10 10:01:25'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-10 10:03:28 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-10 10:01:28'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-10 10:03:31 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-10 10:01:31'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-10 10:03:34 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-10 10:01:34'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-10 10:03:42 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-10 10:01:42'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-10 10:03:43 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT `s`.`id`, `s`.`call_id`, `c`.`conversation_id`, `s`.`from_user_id`, `s`.`to_user_id`, `s`.`type`, `s`.`payload`, `s`.`created_at`, `u`.`email` AS `from_email`
FROM `signaling_messages` `s`
JOIN `calls` `c` ON `c`.`id` = `s`.`call_id`
JOIN `call_participants` `cp` ON `cp`.`call_id` = `c`.`id`
LEFT JOIN `users` `u` ON `u`.`id` = `s`.`from_user_id`
WHERE `cp`.`user_id` = 1
AND `s`.`type` = 'offer'
AND `s`.`id` > 0
AND `s`.`from_user_id` != 1
AND `s`.`created_at` >= '2026-07-10 10:01:43'
ORDER BY `s`.`id` ASC
ERROR - 2026-07-10 10:03:44 --> Query error: Table 'admin_stadmin_internal_portal.users' doesn't exist - Invalid query: SELECT q.*, u.name AS recipient_name, s.name AS submitter_name, r.name AS rule_name, r.code AS rule_code, r.points AS rule_points, c.name AS category_name, t.reference_label
FROM `reward_approval_queue` `q`
LEFT JOIN `users` `u` ON `u`.`id` = `q`.`user_id`
LEFT JOIN `users` `s` ON `s`.`id` = `q`.`submitted_by`
LEFT JOIN `reward_rules` `r` ON `r`.`id` = `q`.`rule_id`
LEFT JOIN `reward_categories` `c` ON `c`.`id` = `r`.`category_id`
LEFT JOIN `reward_transactions` `t` ON `t`.`id` = `q`.`transaction_id`
WHERE `q`.`status` = 'pending'
AND `q`.`source_module` = 'spl'
ORDER BY `q`.`submitted_at` DESC
 LIMIT 20
ERROR - 2026-07-10 04:39:10 --> Severity: Deprecated Notice --> strtolower(): Passing null to parameter #1 ($string) of type string is deprecated C:\wamp64\www\Office_management_system\system\core\Input.php 912
ERROR - 2026-07-10 10:09:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\Office_management_system\system\core\Exceptions.php:276) C:\wamp64\www\Office_management_system\system\helpers\url_helper.php 565
ERROR - 2026-07-10 10:42:24 --> 404 Page Not Found: 
