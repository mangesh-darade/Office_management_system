<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-06-25 10:30:22 --> Severity: Deprecated Notice --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\wamp64\www\Office_management_system\application\views\projects\form.php 82
