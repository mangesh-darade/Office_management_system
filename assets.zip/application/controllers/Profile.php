<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->library(['session', 'upload']);
        $this->load->helper(['url', 'form','schema_columns']);
        $this->load->model(['User_model','Employee_model']);
    }

    public function index()
    {
        $uid = (int)$this->session->userdata('user_id');
        if (!$uid) { redirect('login'); return; }
        $user = $this->User_model->get($uid);
        $employee = null;
        if (!empty($user)) {
            $employee = $this->Employee_model->get_by_user_id((int)$user->id);
        }
        $this->load->view('profile/index_enhanced', [
            'user' => $user,
            'employee' => $employee
        ]);
    }
    
    public function edit()
    {
        $uid = (int)$this->session->userdata('user_id');
        if (!$uid) { redirect('login'); return; }
        
        $user = $this->User_model->get($uid);
        $employee = null;
        if (!empty($user)) {
            $employee = $this->Employee_model->get_by_user_id((int)$user->id);
        }
        
        if ($this->input->method() === 'post') {
            // Handle profile update
            $data = [
                'name' => trim($this->input->post('name')),
                'email' => trim($this->input->post('email')),
                'phone' => trim($this->input->post('phone')),
                'updated_at' => date('Y-m-d H:i:s')
            ];
            
            // Handle password change
            $password = $this->input->post('password');
            $current_password = $this->input->post('current_password');
            
            if (!empty($password)) {
                // Verify current password first
                if (empty($current_password)) {
                    $this->session->set_flashdata('error', 'Please enter your current password to change your password!');
                    redirect('profile/edit');
                    return;
                }
                
                // Get current user data to verify password
                $current_user = $this->User_model->get($uid);
                if (!password_verify($current_password, $current_user->password)) {
                    $this->session->set_flashdata('error', 'Current password is incorrect!');
                    redirect('profile/edit');
                    return;
                }
                
                // Validate new password using settings
                $this->load->helper('password');
                $validation = validate_password_strength($password); // Uses settings automatically
                
                if (!$validation['valid']) {
                    $this->session->set_flashdata('error', implode(' ', $validation['errors']));
                    redirect('profile/edit');
                    return;
                }
                
                $confirm_password = $this->input->post('confirm_password');
                if ($password !== $confirm_password) {
                    $this->session->set_flashdata('error', 'New passwords do not match!');
                    redirect('profile/edit');
                    return;
                }
                
                // Update password_hash field (check which field name is used)
                $password_field = 'password_hash';
                if (!schema_table_has_column($this->db, 'users', $password_field)) {
                    $password_field = 'password';
                }
                $data[$password_field] = password_hash($password, PASSWORD_DEFAULT);
                
                // Update password_changed_at if field exists
                if (schema_table_has_column($this->db, 'users', 'password_changed_at')) {
                    $data['password_changed_at'] = date('Y-m-d H:i:s');
                }
                
                // Log password change if audit logging enabled
                $this->load->model('Setting_model', 'settings');
                $this->load->model('Security_audit_model', 'audit');
                if ($this->settings->get_setting('security_audit_password_change', 'no') === 'yes') {
                    $ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
                    $this->audit->log('password_changed', $uid, "User changed password", $ip);
                }
                $success_msg = get_notification_message('profile', 'password_change', 'success');
                $this->session->set_flashdata('success', $success_msg);
            }
            
            // Handle avatar upload
            if (!empty($_FILES['avatar']['name'])) {
                $config = [
                    'upload_path' => './assets/uploads/avatars/',
                    'allowed_types' => 'jpg|jpeg|png|gif',
                    'max_size' => 2048,
                    'file_name' => 'avatar_' . $uid . '_' . time(),
                    'overwrite' => TRUE,
                    'remove_spaces' => TRUE
                ];
                
                if (!is_dir($config['upload_path'])) {
                    mkdir($config['upload_path'], 0755, TRUE);
                }
                
                $this->upload->initialize($config);
                if ($this->upload->do_upload('avatar')) {
                    $upload_data = $this->upload->data();
                    $data['avatar'] = 'assets/uploads/avatars/' . $upload_data['file_name'];
                    
                    // Delete old avatar if exists
                    if (!empty($user->avatar) && file_exists('./' . $user->avatar)) {
                        unlink('./' . $user->avatar);
                    }
                }
            }
            
            // Update user data
            $this->db->where('id', $uid)->update('users', $data);
            
            // Update employee data if exists
            if ($employee) {
                $emp_fields = [
                    'first_name' => trim((string)$this->input->post('first_name')),
                    'last_name' => trim((string)$this->input->post('last_name')),
                    'department' => trim((string)$this->input->post('department')),
                    'designation' => trim((string)$this->input->post('designation')),
                    'phone' => trim((string)$this->input->post('phone')),
                    'address' => trim((string)$this->input->post('address')),
                    'bio' => trim((string)$this->input->post('bio')),
                ];
                $emp_data = [];
                foreach ($emp_fields as $col => $val) {
                    if (schema_table_has_column($this->db, 'employees', $col)) {
                        $emp_data[$col] = $val;
                    }
                }
                if (!empty($emp_data)) {
                    $this->db->where('user_id', $uid)->update('employees', $emp_data);
                }
            }
            
            $success_msg = get_notification_message('profile', 'update', 'success');
            $this->session->set_flashdata('success', $success_msg);
            redirect('profile');
        }
        
        $this->load->view('profile/edit', [
            'user' => $user,
            'employee' => $employee
        ]);
    }
    
    public function remove_avatar()
    {
        if ($this->input->method() !== 'post') { show_error('Method Not Allowed', 405); }
        $uid = (int)$this->session->userdata('user_id');
        if (!$uid) { redirect('login'); return; }
        
        $user = $this->User_model->get($uid);
        if (!empty($user->avatar) && file_exists('./' . $user->avatar)) {
            unlink('./' . $user->avatar);
        }
        
        $this->db->where('id', $uid)->update('users', ['avatar' => null]);
        $this->session->set_flashdata('success', 'Avatar removed successfully!');
        redirect('profile/edit');
    }
    
    public function delete_profile()
    {
        $uid = (int)$this->session->userdata('user_id');
        if (!$uid) { redirect('login'); return; }
        
        // Only allow admins to delete their own profile or users to delete themselves
        $role_id = (int)$this->session->userdata('role_id');
        if ($role_id !== 1) { // Only admins can delete profiles
            $this->session->set_flashdata('error', 'Only administrators can delete profiles!');
            redirect('profile');
            return;
        }
        
        if ($this->input->method() === 'post') {
            $confirmation = trim($this->input->post('confirmation'));
            if ($confirmation !== 'DELETE') {
                $this->session->set_flashdata('error', 'Please type DELETE exactly to confirm profile deletion!');
                redirect('profile/edit');
                return;
            }
            
            try {
                // Get user data before deletion
                $user = $this->User_model->get($uid);
                
                // Delete avatar file if exists
                if (!empty($user->avatar) && file_exists('./' . $user->avatar)) {
                    unlink('./' . $user->avatar);
                }
                
                // Delete employee record if exists
                $this->db->where('user_id', $uid)->delete('employees');
                
                // Delete user record
                $this->db->where('id', $uid)->delete('users');
                
                // Destroy session and redirect to login
                $this->session->sess_destroy();
                
                echo '<script>
                    alert("Profile deleted successfully! You will be redirected to the login page.");
                    window.location.href = "' . site_url('login') . '";
                </script>';
                exit;
                
            } catch (Exception $e) {
                $this->session->set_flashdata('error', 'Failed to delete profile: ' . $e->getMessage());
                redirect('profile/edit');
            }
        }
        
        redirect('profile/edit');
    }
}
