<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-07-08 10:14:32 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\wamp64\www\Office_management_system\system\database\drivers\mysqli\mysqli_driver.php 212
ERROR - 2026-07-08 10:14:32 --> Unable to connect to the database
ERROR - 2026-07-08 16:20:17 --> Severity: error --> Exception: Call to undefined function attendance_punch_resolve_time_columns() C:\wamp64\www\Office_management_system\application\helpers\attendance_manage_helper.php 17
ERROR - 2026-07-08 16:22:14 --> Severity: error --> Exception: Call to undefined function attendance_punch_resolve_time_columns() C:\wamp64\www\Office_management_system\application\helpers\attendance_manage_helper.php 17
ERROR - 2026-07-08 11:26:56 --> Unable to load the requested class: Training_csv_import
ERROR - 2026-07-08 16:57:02 --> Severity: Deprecated Notice --> ctype_digit(): Argument of type null will be interpreted as string in the future C:\wamp64\www\Office_management_system\system\libraries\Pagination.php 527
ERROR - 2026-07-08 16:57:02 --> Severity: Deprecated Notice --> ctype_digit(): Argument of type null will be interpreted as string in the future C:\wamp64\www\Office_management_system\system\libraries\Pagination.php 527
ERROR - 2026-07-08 16:57:03 --> Query error: Unknown column 'DISTINCT' in 'field list' - Invalid query: SELECT `DISTINCT` `category`
FROM `system_settings`
ORDER BY `category`
ERROR - 2026-07-08 16:57:03 --> Severity: Deprecated Notice --> fputcsv(): the $escape parameter must be provided as its default value will change C:\wamp64\www\Office_management_system\application\controllers\Daily_activity.php 304
ERROR - 2026-07-08 11:27:39 --> Unable to load the requested class: Training_csv_import
ERROR - 2026-07-08 16:57:40 --> Query error: Unknown column 'DISTINCT' in 'field list' - Invalid query: SELECT `DISTINCT` `category`
FROM `system_settings`
ORDER BY `category`
ERROR - 2026-07-08 16:57:40 --> Severity: Deprecated Notice --> ctype_digit(): Argument of type null will be interpreted as string in the future C:\wamp64\www\Office_management_system\system\libraries\Pagination.php 527
ERROR - 2026-07-08 16:57:42 --> Severity: Deprecated Notice --> ctype_digit(): Argument of type null will be interpreted as string in the future C:\wamp64\www\Office_management_system\system\libraries\Pagination.php 527
ERROR - 2026-07-08 17:27:51 --> Severity: Deprecated Notice --> fgetcsv(): the $escape parameter must be provided as its default value will change C:\wamp64\www\Office_management_system\application\helpers\csv_import_helper.php 36
ERROR - 2026-07-08 17:27:51 --> Severity: Deprecated Notice --> fgetcsv(): the $escape parameter must be provided as its default value will change C:\wamp64\www\Office_management_system\application\controllers\Tasks.php 2069
ERROR - 2026-07-08 17:27:51 --> Severity: Deprecated Notice --> fgetcsv(): the $escape parameter must be provided as its default value will change C:\wamp64\www\Office_management_system\application\controllers\Tasks.php 2069
ERROR - 2026-07-08 17:27:51 --> Severity: Deprecated Notice --> fgetcsv(): the $escape parameter must be provided as its default value will change C:\wamp64\www\Office_management_system\application\controllers\Tasks.php 2069
ERROR - 2026-07-08 17:27:51 --> Severity: Deprecated Notice --> fgetcsv(): the $escape parameter must be provided as its default value will change C:\wamp64\www\Office_management_system\application\controllers\Tasks.php 2069
ERROR - 2026-07-08 17:27:51 --> Severity: Deprecated Notice --> fgetcsv(): the $escape parameter must be provided as its default value will change C:\wamp64\www\Office_management_system\application\controllers\Tasks.php 2069
