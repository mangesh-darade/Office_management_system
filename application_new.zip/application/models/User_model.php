<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require_once APPPATH . 'core/Schema_columns_trait.php';

class User_model extends CI_Model {
    use Schema_columns_trait;
    private $table = 'users';

    public function __construct(){
        parent::__construct();
        $this->load->database();
        $this->load->helper('hierarchy_filter');
        $this->ensure_schema();
    }

    public function ensure_schema(){
        static $done = false;
        if ($done) { return; }
        $done = true;
        if ($this->db->table_exists($this->table)){
            if (!$this->has_column('notify_attendance')){
                $this->db->query("ALTER TABLE `".$this->table."` ADD `notify_attendance` TINYINT(1) NOT NULL DEFAULT 1");
            }
        }
    }

    public function get_by_email($email){
        return $this->db->get_where($this->table, ['email' => $email])->row();
    }

    public function get_by_phone($phone){
        if (!$this->has_column('phone')){
            return null;
        }
        return $this->db->get_where($this->table, ['phone' => $phone])->row();
    }

    /**
     * Fetch user for authentication using email or phone number.
     * Checks both fields to support login with either identifier.
     */
    public function get_by_login($identifier){
        $this->db->from($this->table);
        
        // Check if identifier looks like an email
        if (filter_var($identifier, FILTER_VALIDATE_EMAIL)) {
            $this->db->where('email', $identifier);
        } else {
            // For non-email, check both phone and email fields
            $this->db->group_start();
            if ($this->has_column('phone')) {
                $this->db->where('phone', $identifier);
            }
            $this->db->or_where('email', $identifier);
            $this->db->group_end();
        }
        
        return $this->db->get()->row();
    }

    // Backwards compat
    public function get($id){
        return $this->db->get_where($this->table, ['id' => (int)$id])->row();
    }

    // Preferred name in controllers
    public function find($id){ return $this->get($id); }

    public function create($data){
        $this->db->insert($this->table, $data);
        return $this->db->insert_id();
    }

    // Preferred name in controllers
    public function insert($data){ return $this->create($data) > 0; }

    public function count_all(){
        return $this->db->count_all($this->table);
    }

    /**
     * List users with optional simple search by name/email. Limit default 250.
     * Optionally restrict to specific role IDs when $roleIds is a non-empty array.
     */
    /**
     * Get all users, useful for dropdowns
     */
    public function get_all($limit = 1000){
        $this->db->from($this->table);
        if ($this->has_column('status')){
            $this->db->where('status !=', 'inactive');
        }
        if ($this->has_column('first_name')){
            $this->db->order_by('first_name', 'ASC');
        } else {
            $this->db->order_by('name', 'ASC');
        }
        apply_role_hierarchy_filter($this->db, 'id');
        $this->db->limit((int)$limit);
        return $this->db->get()->result();
    }

    /**
     * Active users from `users` for Training & Assessment assign dropdown.
     * Does not apply role hierarchy (admins and HR need the full list when assigning tests).
     */
    public function list_for_training_assign_dropdown($limit = 15000)
    {
        $this->db->from($this->table);
        if ($this->has_column('status')) {
            $this->db->where('status !=', 'inactive');
        }
        if ($this->has_column('name')) {
            $this->db->order_by('name', 'ASC');
        } elseif ($this->has_column('first_name')) {
            $this->db->order_by('first_name', 'ASC');
            if ($this->has_column('last_name')) {
                $this->db->order_by('last_name', 'ASC');
            }
        }
        $this->db->order_by('email', 'ASC');
        $this->db->limit((int) $limit);
        return $this->db->get()->result();
    }

    public function list_users($q = '', $limit = 250, $roleIds = null, $userId = null){
        $this->db->from($this->table);
        // Hide soft-deleted users from the grid if status column exists
        if ($this->has_column('status')){
            $this->db->where('status !=', 'inactive');
        }
        if ($userId !== null){
            $this->db->where('id', (int)$userId);
        }
        if ($userId === null) {
            apply_role_hierarchy_filter($this->db, 'id');
        }
        // Optional role-based filter (used to scope list by group type)
        if (is_array($roleIds) && !empty($roleIds) && $this->has_column('role_id')){
            $roleIds = array_map('intval', $roleIds);
            $this->db->where_in('role_id', $roleIds);
        }
        if ($q !== ''){
            $this->db->group_start();
            $this->db->like('name', $q);
            $this->db->or_like('email', $q);
            $this->db->group_end();
        }
        $this->db->order_by('id', 'DESC');
        $this->db->limit((int)$limit);
        return $this->db->get()->result();
    }

    public function email_exists($email, $exclude_id = null){
        $this->db->from($this->table);
        $this->db->where('email', $email);
        if ($exclude_id !== null){
            $this->db->where('id !=', (int)$exclude_id);
        }
        return $this->db->count_all_results() > 0;
    }

    public function phone_exists($phone, $exclude_id = null){
        if (!$this->has_column('phone')){
            return false;
        }
        $this->db->from($this->table);
        $this->db->where('phone', $phone);
        if ($exclude_id !== null){
            $this->db->where('id !=', (int)$exclude_id);
        }
        return $this->db->count_all_results() > 0;
    }

    public function update($id, $data){
        if (isset($data['id'])) unset($data['id']);
        $this->db->where('id', (int)$id);
        return $this->db->update($this->table, $data);
    }

    public function delete($id){
        // Prefer soft delete to avoid FK constraint errors
        if ($this->has_column('status')){
            $this->db->where('id', (int)$id);
            return $this->db->update($this->table, array('status' => 'inactive'));
        }
        // If no status column, do not hard-delete to avoid FK crashes
        return false;
    }
}
